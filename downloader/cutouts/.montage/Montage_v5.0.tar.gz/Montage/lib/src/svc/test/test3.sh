#!/bin/sh

test3 < script

#!/bin/sh

test1 < script
